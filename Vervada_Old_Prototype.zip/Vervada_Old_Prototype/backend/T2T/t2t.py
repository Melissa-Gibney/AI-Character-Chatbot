from T2T import open_ai_model

class T2T():

    def createPrompt(self, message, author):# context):
        return f"{author} says: {message}"

    def getOpenAIOutput(self, message, author, context):
        open_ai_model.userRequest = self.createPrompt(self, message, author)
        return open_ai_model.getCompletion()