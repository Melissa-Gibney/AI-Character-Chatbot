from flask_restful import Resource, reqparse, fields, marshal_with, abort

#Variables for Discord Endpoint
discordArgs = reqparse.RequestParser()
discordArgs.add_argument("message", type=str, required=True, help="You must include a message in your request")
discordArgs.add_argument("response", type=str, required=False, help="The T2T generated response to the message")
discordArgs.add_argument("author", type=str, required=True, help="You must include the message author in your request")
discordArgs.add_argument("inVoiceChat", type=bool, required=True, help="You must include whether the bot is in a voice chat")

#Fields for Discord Endpoint
discordFields = {
    "message": fields.String,
    "author": fields.String,
    "inVoiceChat": fields.Boolean
}

#Get all info about the endpoint
class DiscordEndpoint(Resource):

    message = "Vervada, can you hear me? What are you doing?"
    response = "testResponse"
    author = "testAuthor"
    inVoiceChat = False

    @marshal_with(discordFields)
    def get(self):
        return {"message": self.message,
                "response": self.response,
                "author": self.author,
                "inVoiceChat": self.inVoiceChat
                }
    
    @marshal_with(discordFields)
    def post(self):
        return {"message": "postMessage",
                "response": "postResponse",
                "author": "postAuthor",
                "inVoiceChat": True
                }
    
    def put(self):
        return {"response": self.response}