# import asyncio
# import requests
# import aiohttp
from flask import Flask, jsonify, url_for
from flask_cors import CORS
from flask_restful import Api, Resource, reqparse, fields, marshal_with, abort
from T2T import t2t
#from STT import stt
#from Endpoints import discord_endpoint

app = Flask(__name__)
cors = CORS(app, origins="*")
api = Api(app)

discordBotKey = "MTM0MDE5NjQwNDk2NjA2NDIyMA.GC-8wQ.Rs_wnMrwQd8z5X2UlmTC0gH4cD2-YB6OSzDZbk"

#Variables for Discord Endpoint
discordArgs = reqparse.RequestParser()
discordArgs.add_argument("message", type=str, required=True, help="You must include a message in your request")
discordArgs.add_argument("response", type=str, required=False, help="The T2T generated response to the message")
discordArgs.add_argument("author", type=str, required=True, help="You must include the message author in your request")
discordArgs.add_argument("inVoiceChat", type=bool, required=True, help="You must include whether the bot is in a voice chat")

#Fields for Discord Endpoint
discordFields = {
    "message": fields.String,
    "response": fields.String,
    "author": fields.String,
    "inVoiceChat": fields.Boolean
}

#Get all info about the endpoint
class DiscordMessageEndpoint(Resource):

    message = "Vervada, can you hear me? What are you doing?"
    response = "testResponse"
    author = "testAuthor"
    inVoiceChat = False

    @marshal_with(discordFields)
    def get(self):
        return {"message": self.message,
                "response": self.response,
                "author": self.author,
                "inVoiceChat": self.inVoiceChat
                }
    
    @marshal_with(discordFields)
    def post(self):
        args = discordArgs.parse_args()
        self.message = args["message"]
        self.author = args["author"]
        self.inVoiceChat = args["inVoiceChat"]
        self.response = t2t.T2T.getOpenAIOutput(t2t.T2T, self.message, self.author, None)
        return {"response": self.response}
    
    def put(self):
        args = discordArgs.parse_args()
        self.response = t2t.T2T.getOpenAIOutput(t2t.T2T, self.message, self.author, None)
        return {"response": self.response}

api.add_resource(DiscordMessageEndpoint, "/api/discord/message/")

if __name__ == "__main__":
    app.run(debug=True, port=8080)